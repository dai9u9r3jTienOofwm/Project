package com.badlogic.game.model;

import com.badlogic.game.collision.GeometryRec;
import com.badlogic.game.view.Image;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Boss extends BaseEntity {
    private int health = 100;
    private int currentPhrase;
    private BossBulletPattern bulletPattern;
    private float stateTime;

    public Boss(float x, float y, BossBulletPattern pattern) {
        super(new Texture("boss.png"), x, y);
        this.currentPhrase = 1;
        this.bounds = new GeometryRec(x, y, width, height);
        this.bulletPattern = new BossBulletPattern(pattern);
        this.stateTime = 0;
    }

    @Override
    public void update(float deltaTime) {
        stateTime += deltaTime;
         bulletPattern.executeAttack(stateTime);

         if (health <= 75 && currentPhrase == 1 ) {
            transitionToSpellCard1();
         }

         if (health <= 5 && currentPhrase == 2) {
            health = 100;
            transitionToSpellCard2();
         }

         if (!alive) {
            onDestroy();
         }
    }

    @Override
    public void render(SpriteBatch batch) {
        batch.draw(texture, x, y);
    }

    @Override
    public GeometryRec getBounds() {
        return super.getBounds();
    }

    @Override
    public boolean isAlive() {
        return health <= 0;
    }

    private void transitionToSpellCard1() {
        currentPhrase = 2;
        bulletPattern.changeCard(BossBulletPattern.PHRASE_TWO);
    }
    private void transitionToSpellCard2() {
        currentPhrase = 3;
        bulletPattern.changeCard(BossBulletPattern.PHRASE_THREE);
    }

    @Override
    public void onDestroy() {
        alive = false;
        GameScreen.removeEntity(this);
    }
}
