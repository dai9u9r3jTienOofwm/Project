package com.badlogic.game.model;

public class BossBulletPattern {

}
