package com.badlogic.game.model;

public enum BulletType {
    PLAYER_BULLET,
    ENEMY_BULLET,
    BOSS_BULLET
}
