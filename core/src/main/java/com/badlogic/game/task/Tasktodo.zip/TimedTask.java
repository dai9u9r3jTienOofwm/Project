package com.badlogic.game.task;

public class TimedTask extends TaskBase {
    private float delay;
    private float elapsed;

    public TimedTask(float delay) {
        this.delay = delay;
        this.elapsed = 0;
    }

    @Override
    public void update(float delta) {
        if (isFinished()) return;

        elapsed += delta;
        if (elapsed >= delay) {
            setFinished(true);
            onComplete();
        }
    }

    protected void onComplete() {
    }
    
}
