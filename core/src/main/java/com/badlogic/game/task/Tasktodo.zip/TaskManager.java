package com.badlogic.game.task;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TaskManager {
    private static TaskManager instance;
    private final List<TaskBase> tasks;

    private TaskManager() {
        tasks = new ArrayList<>();
    }

    public static TaskManager getInstance() {
        if (instance == null) {
            instance = new TaskManager();
        }
        return instance;
    }

    public void add(TaskBase task) {
        if (task == null) return;
        if (!tasks.contains(task)) {
            tasks.add(task);
        }
    }

    public void updateAll(float delta) {
        Iterator<TaskBase> iterator = tasks.iterator();
        while (iterator.hasNext()) {
            TaskBase task = iterator.next();
            task.update(delta);
            if (task.isFinished()) {
                iterator.remove();
            }
        }
    }

    public void removeFinished() {
        tasks.removeIf(TaskBase::isFinished);
    }

    public void clear() {
        tasks.clear();
    }
}
