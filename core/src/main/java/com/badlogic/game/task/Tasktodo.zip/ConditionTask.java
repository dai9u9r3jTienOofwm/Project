package com.badlogic.game.task;

import java.util.function.Predicate;
public class ConditionTask extends TaskBase {
    private final Predicate<Float> condition;
    
    public ConditionTask(Predicate<Float> condition) {
        this.condition = condition;
    }

    @Override
    public void update(float delta) {
        if(!isFinished() && condition.test(delta)) {
            setFinished(true);
        }
    }
}
