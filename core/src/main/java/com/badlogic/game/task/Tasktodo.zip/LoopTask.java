package com.badlogic.game.task;

public class LoopTask extends TaskBase {
    private float interval; // khoang tgian giua cac lan lap
    private int repeatCount; // so lan lap
    private float elapsed;

    public LoopTask(float interval, int repeatCount) {
        this.interval = interval;
        this.repeatCount = repeatCount;
        this.elapsed = 0f;
    }

    @Override
    public void update(float delta) {
        if (isFinished()) {
            return;
        }
        elapsed += delta;
        while(elapsed >= interval && repeatCount > 0) {
            onRepeat();
            repeatCount--;
            elapsed -= interval;
            if(repeatCount <= 0) {
                setFinished(true);
                break;
            }
        }
    }

    public void onRepeat() {

    }
}
