package com.badlogic.game.task;

import java.util.function.Supplier;

public class ItemSpamTask extends TaskBase {
    private final float spawnInterval;
    private float accumulatedTime;
    private final Supplier<Object> itemSupplier;

    public ItemSpamTask(float spawnInterval, Supplier<Object> itemSupplier) {
        this.spawnInterval = spawnInterval;
        this.accumulatedTime = 0f;
        this.itemSupplier = itemSupplier;
    }

    @Override
    public void update(float delta) {
        if (isFinished()) return;
        accumulatedTime += delta;
        if (accumulatedTime >= spawnInterval) {
            spawnItem();
            accumulatedTime -= spawnInterval;
        }
    }

    public void spawnItem() {
        Object newItem = itemSupplier.get();
        System.out.println("Spawned item: " + newItem);
    }
}