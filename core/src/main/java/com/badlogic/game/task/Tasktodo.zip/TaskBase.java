package com.badlogic.game.task;

public abstract class TaskBase {
    private boolean isFinished = false;

    public boolean isFinished() {
        return isFinished;
    }

    public void setFinished(boolean isFinished) {
        this.isFinished = isFinished;
    }

    public abstract void update(float delta);
}
